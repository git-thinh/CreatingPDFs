namespace TuesPechkin
{
    public enum Unit
    {
        Inches,
        Millimeters,
        Centimeters
    }
}