﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TuesPechkin
{
    public sealed class PostItem
    {
        public string Name { get; set; }

        public string Value { get; set; }

        public bool IsFile { get; set; }
    }
}
