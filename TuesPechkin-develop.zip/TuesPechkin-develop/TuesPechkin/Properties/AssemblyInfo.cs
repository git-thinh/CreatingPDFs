﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("TuesPechkin")]
[assembly: AssemblyDescription(".NET wrapper for wkhtmltopdf; supports 32-bit, 64-bit, multi-threaded and IIS environments.")]
[assembly: AssemblyProduct("TuesPechkin")]
[assembly: AssemblyCopyright("Copyright 2014 Derek Gray")]
[assembly: AssemblyVersion("2.1.1")]

[assembly: ComVisible(false)]
[assembly: Guid("11f63696-7105-436d-9ec6-2fee54c40b11")]
